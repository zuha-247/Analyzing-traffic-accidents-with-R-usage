# Load necessary libraries
library(dplyr)

# Load the dataset
data <- read.csv("Traffic Accidents in Pakistan.csv")

#Task3:Descriptive Statistics
#Objective: Summarize the dataset to understand its structure and key statistics.
# View the structure of the dataset
str(data)

# Summary statistics
summary(data)

# Check for missing values
colSums(is.na(data))


# Check for duplicate rows
sum(duplicated(data))

#Task 4: Data Preprocessing
#Objective: Clean and prepare the data for analysis.

#1)Handling missing values:
#Remove rows with missing values:
data <- na.omit(data)
str(data$`Total.Number.of.Accident`)
colnames(data)
#Alternatively, fill missing values with the mean (for numerical columns):
# Corrected line - fill NAs in Total.Number.of.Accident with its mean
data$`Total.Number.of.Accident`[is.na(data$`Total.Number.of.Accident`)] <- mean(data$`Total.Number.of.Accident`, na.rm = TRUE)
data$`Accident.Fatal`[is.na(data$`Accident.Fatal`)] <- mean(data$`Accident.Fatal`, na.rm = TRUE)
data$`Accident.Non.Fatal`[is.na(data$`Accident.Non.Fatal`)] <- mean(data$`Accident.Non.Fatal`, na.rm = TRUE)
data$`Person.Injured`[is.na(data$`Person.Injured`)] <- mean(data$`Person.Injured`, na.rm = TRUE)
data$`Total.Number.of.vehicles.Involves`[is.na(data$`Total.Number.of.vehicles.Involves`)] <- mean(data$`Total.Number.of.vehicles.Involves`, na.rm = TRUE)
# Check for missing values=Verifying
colSums(is.na(data))

#Removing Duplicated Data:
data <- data[!duplicated(data), ]
# Check for duplicate rows=Verifying
sum(duplicated(data))

#Since upper se Total number of accidents 126 nikly which means shi se missing values handle nhi hui so:
# Compare the two columns (if both exist)
head(data[, c("Total.Number.of.Accident", "Total Number of Accident")])
#Agr duplicated column nikla hai and it is empty then remove it:
data$`Total Number of Accident` <- NULL

#ab verify kiya hai:
colSums(is.na(data))

#Converting Categorical Variables:
data$Total.Number.of.Accident <- as.factor(data$Total.Number.of.Accident)
data$Accident.Fatal <- as.factor(data$Accident.Fatal)
data$Accident.Non.Fatal <- as.factor(data$Accident.Non.Fatal)
data$Person.Injured <- as.factor(data$Person.Injured)
data$Total.Number.of.vehicles.Involves <- as.factor(data$Total.Number.of.vehicles.Involves)

#Detecting and Handling Outliers:
# Identify numeric columns in your dataset
numeric_cols <- names(data)[sapply(data, is.numeric)]

# Set up plotting area
par(mfrow = c(2, 3))  # 2 rows, 3 columns

# Boxplots for each column BEFORE removing outliers
for (col in numeric_cols) {
  boxplot(data[[col]], main = paste("Before -", col), col = "lightblue")
}

# Outlier removal block (already provided)
for (col in numeric_cols) {
  Q1 <- quantile(data[[col]], 0.25, na.rm = TRUE)
  Q3 <- quantile(data[[col]], 0.75, na.rm = TRUE)
  IQR <- Q3 - Q1
  data <- data[data[[col]] >= (Q1 - 1.5 * IQR) & data[[col]] <= (Q3 + 1.5 * IQR), ]
}
# Reset plotting area
par(mfrow = c(2, 3))  # 2 rows, 3 columns

# Boxplots for each column AFTER removing outliers
for (col in numeric_cols) {
  boxplot(data[[col]], main = paste("After -", col), col = "lightgreen")
}

# Identify numeric columns
numeric_cols <- names(data)[sapply(data, is.numeric)]

# Apply standard scaling to each numeric column
data[numeric_cols] <- lapply(data[numeric_cols], scale)

#Task 5: Exploratory Data Analysis (EDA)

install.packages("GGally")
install.packages("reshape2")

# Load necessary libraries
library(ggplot2)
library(GGally)
library(reshape2)

# View structure of your dataset
str(data)

library(tidyr)
library(ggplot2)
library(dplyr)
# Read your data
data <- read.csv("Traffic Accidents in Pakistan.csv")  # Skip first row with "Pakistan" heading

colnames(data)

# Rename column if necessary
colnames(data)[1] <- "Month_Year"

# Reshape the data to long format
long_data <- pivot_longer(data,
                          cols = c("Accident.Fatal", "Accident.Non.Fatal"),
                          names_to = "Accident_Type",
                          values_to = "Count")

# Plot the stacked bar chart
ggplot(long_data, aes(x = Month_Year, y = Count, fill = Accident_Type)) +
  geom_bar(stat = "identity") +
  scale_fill_manual(values = c("Accident.Fatal" = "darkgreen", "Accident.Non.Fatal" = "orange")) +
  labs(title = "Accidents by Month",
       x = "Month - Year",
       y = "Number of Accidents",
       fill = "Accident Type") +
  theme_minimal() +
  theme(axis.text.x = element_text(angle = 45, hjust = 1))

# Bar chart: Count of records per Year/Month
ggplot(data, aes(x = Month...Year)) +
  geom_bar(fill = "steelblue") +
  theme(axis.text.x = element_text(angle = 90)) +
  ggtitle("Number of Records per Year") +
  xlab("Year") + ylab("Total.Number.of.Accident ")

# Pie chart: Distribution of records per Year/Month
library(dplyr)
data <- read.csv("Traffic Accidents in Pakistan.csv")  # Skip first row with "Pakistan" heading

str(data)

data %>%
  filter(!is.na(`Month...Year`)) %>%
  group_by(`Month...Year`) %>%
  summarise(count = n()) %>%
  ggplot(aes(x = "", y = count, fill = `Month...Year`)) +
  geom_bar(stat = "identity", width = 1) +
  coord_polar("y") +
  labs(title = "Distribution of Records per Month-Year") +
  theme_void()

str(data$Total.Number.of.Accident)
# Convert factor to numeric
data$Total.Number.of.Accident <- as.numeric(as.character(data$Total.Number.of.Accident))


# Histogram: Total Number of Accidents
ggplot(data, aes(x = Total.Number.of.Accident)) +
  geom_histogram(binwidth = 500, fill = "orange", color = "black") +
  ggtitle("Histogram of Total Accidents") +
  xlab("Total Number of Accidents")

# Scatter plot: Total Accidents vs Person Killed
ggplot(data, aes(x = Total.Number.of.Accident, y = Person.Killed)) +
  geom_point(color = "red", alpha = 0.6) +
  ggtitle("Scatter Plot: Accidents vs Killed") +
  xlab("Total Accidents") + ylab("People Killed")

# Density plot: Distribution of Person Injured
ggplot(data, aes(x = Person.Injured)) +
  geom_density(fill = "green", alpha = 0.5) +
  ggtitle("Density Plot: Person Injured")

# Density plot: Person Killed grouped by Year (if grouping makes sense)
ggplot(data, aes(x = Person.Killed, fill = Month...Year)) +
  geom_density(alpha = 0.4) +
  ggtitle("Density Plot: Killed by Year") +
  theme(legend.position = "none")  # Remove legend if too many categories

# Pair plot: Select key numeric variables
colnames(data)
sum(is.na(data$Total.Number.of.Accident))
sum(is.na(data$Person.Killed))
# Remove rows with missing values
data_clean <- data[!is.na(data$Total.Number.of.Accident) & !is.na(data$Person.Killed), ]
str(data$Total.Number.of.Accident)
str(data$Person.Killed)

# Convert from matrix to vector if scaled
data$Person.Killed <- as.numeric(data$Person.Killed)
str(data$Person.Killed)
library(GGally)
ggpairs(data[, c("Total.Number.of.Accident", "Person.Killed")])



# Heatmap of correlation matrix for numeric variables
# Step 1: Compute the correlation matrix for numeric variables
numeric_data <- data[, sapply(data, is.numeric)]  # Get numeric columns
cor_matrix <- cor(numeric_data, use = "complete.obs")  # Calculate correlation matrix

# Step 2: Melt the correlation matrix
library(reshape2)
melted_cor <- melt(cor_matrix)

# Step 3: Plot the heatmap with pastel colors
ggplot(data = melted_cor, aes(x = Var1, y = Var2, fill = value)) +
  geom_tile(color = "white") +
  scale_fill_gradient2(
    low = "lightblue",   # Pastel blue for low values
    high = "lightcoral", # Pastel red for high values
    mid = "lightyellow", # Pastel yellow for mid values
    midpoint = 0         # Middle value is set at 0
  ) +
  ggtitle("Correlation Heatmap") +
  theme(axis.text.x = element_text(angle = 45, hjust = 1))

#Task 7: Statistical Modeling and Inference
#Objective: Perform correlation analysis, simple linear regression (SLR), and multiple linear regression (MLR).

#Correlation Analysis:
cor_matrix <- cor(data[, sapply(data, is.numeric)])
print(cor_matrix)

#Simple Linear Regression (SLR):
slr_model <- lm(Person.Killed ~ Total.Number.of.Accident, data = data)
summary(slr_model)

